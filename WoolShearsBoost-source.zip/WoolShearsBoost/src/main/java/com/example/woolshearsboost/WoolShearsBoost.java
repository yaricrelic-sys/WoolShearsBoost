package com.example.woolshearsboost;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod(WoolShearsBoost.MOD_ID)
public class WoolShearsBoost {
    public static final String MOD_ID = "woolshearsboost";
    private static final float WOOL_BREAK_MULTIPLIER = 1.5F;

    @Mod.EventBusSubscriber(modid = MOD_ID)
    public static class ForgeEvents {
        @SubscribeEvent
        public static void onBreakSpeed(PlayerEvent.BreakSpeed event) {
            if (event.getEntity().getMainHandItem().is(Items.SHEARS)
                    && event.getState().is(BlockTags.WOOL)) {
                event.setNewSpeed(event.getNewSpeed() * WOOL_BREAK_MULTIPLIER);
            }
        }
    }
}
