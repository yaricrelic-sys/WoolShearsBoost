# Wool Shears Boost

A small Minecraft Forge 1.20.1 mod that increases wool breaking speed by 1.5x while the player holds shears in the main hand. Other blocks are unchanged. Wool is not broken instantly.

- Minecraft: 1.20.1
- Forge: 47.2.0
- Java: 17

Build with Gradle 8.8 using `gradle build`.

For multiplayer, the server may need the mod installed too; only use it where client/gameplay modifications are permitted.
